"""Secret storage: the macOS login Keychain via Security.framework (ctypes), with an owner-only
file fallback off macOS (e.g. a Linux cloud session).

Why ctypes and not the ``security`` CLI: ``security add-generic-password -w`` takes the secret on
argv (briefly visible to other processes), and feeding it on stdin (``security -i``) truncates
values near ~4 KB. The Robin token JSON (client id + access + refresh tokens + metadata) is larger
than that, so we call ``SecItem*`` directly, which round-trips large values cleanly.

Only this module touches secrets. Values are opaque bytes to it; callers store/read JSON.
"""
from __future__ import annotations

import hashlib
import os
import sys
from pathlib import Path

MACOS = sys.platform == "darwin"


# --------------------------------------------------------------------------- macOS Keychain (ctypes)

if MACOS:
    import ctypes

    _sec = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/Security.framework/Security")
    _cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
    _u32, _vp = ctypes.c_uint32, ctypes.c_void_p
    _sec.SecKeychainFindGenericPassword.argtypes = [
        _vp, _u32, ctypes.c_char_p, _u32, ctypes.c_char_p, ctypes.POINTER(_u32), ctypes.POINTER(_vp), ctypes.POINTER(_vp)
    ]
    _sec.SecKeychainAddGenericPassword.argtypes = [
        _vp, _u32, ctypes.c_char_p, _u32, ctypes.c_char_p, _u32, ctypes.c_void_p, ctypes.POINTER(_vp)
    ]
    _sec.SecKeychainItemModifyAttributesAndData.argtypes = [_vp, _vp, _u32, ctypes.c_void_p]
    _sec.SecKeychainItemFreeContent.argtypes = [_vp, _vp]
    _sec.SecKeychainItemDelete.argtypes = [_vp]
    _cf.CFRelease.argtypes = [_vp]
    _NOT_FOUND = -25300

    def _find(service: bytes, account: bytes):
        n, data, item = _u32(), _vp(), _vp()
        st = _sec.SecKeychainFindGenericPassword(None, len(service), service, len(account), account,
                                                 ctypes.byref(n), ctypes.byref(data), ctypes.byref(item))
        return st, n, data, item

    def _kc_get(service: str, account: str) -> bytes | None:
        st, n, data, item = _find(service.encode(), account.encode())
        if st == _NOT_FOUND:
            return None
        if st != 0:
            raise OSError(f"keychain read failed: OSStatus {st}")
        try:
            return ctypes.string_at(data, n.value)
        finally:
            _sec.SecKeychainItemFreeContent(None, data)
            _cf.CFRelease(item)

    def _kc_put(service: str, account: str, value: bytes) -> None:
        s, a = service.encode(), account.encode()
        st, _n, data, item = _find(s, a)
        if st == 0:
            _sec.SecKeychainItemFreeContent(None, data)
            try:
                st2 = _sec.SecKeychainItemModifyAttributesAndData(item, None, len(value), value)
            finally:
                _cf.CFRelease(item)
            if st2 != 0:
                raise OSError(f"keychain update failed: OSStatus {st2}")
            return
        if st != _NOT_FOUND:
            raise OSError(f"keychain read failed: OSStatus {st}")
        st = _sec.SecKeychainAddGenericPassword(None, len(s), s, len(a), a, len(value), value, None)
        if st != 0:
            raise OSError(f"keychain add failed: OSStatus {st}")

    def _kc_delete(service: str, account: str) -> bool:
        st, _n, data, item = _find(service.encode(), account.encode())
        if st != 0:
            return False
        _sec.SecKeychainItemFreeContent(None, data)
        try:
            return _sec.SecKeychainItemDelete(item) == 0
        finally:
            _cf.CFRelease(item)


# --------------------------------------------------------------------------- file fallback (non-macOS)


def _state_dir() -> Path:
    base = os.environ.get("XDG_STATE_HOME") or str(Path.home() / ".local" / "state")
    return Path(base) / "robin-mcp"


def _file_path(service: str, account: str) -> Path:
    # Hashed so neither the account nor any secret appears in the file name.
    tag = hashlib.sha256(f"{service}/{account}".lower().encode()).hexdigest()[:16]
    return _state_dir() / f"secret-{tag}"


def _file_get(service: str, account: str) -> bytes | None:
    try:
        return _file_path(service, account).read_bytes() or None
    except FileNotFoundError:
        return None


def _file_put(service: str, account: str, value: bytes) -> None:
    path = _file_path(service, account)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    tmp = path.with_suffix(".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(value)
    os.replace(tmp, path)  # atomic


def _file_delete(service: str, account: str) -> bool:
    try:
        _file_path(service, account).unlink()
        return True
    except FileNotFoundError:
        return False


# --------------------------------------------------------------------------- public API


def get(service: str, account: str) -> bytes | None:
    """The stored secret bytes, or None. First Keychain read may prompt on macOS (Allow/Always Allow)."""
    return _kc_get(service, account) if MACOS else _file_get(service, account)


def put(service: str, account: str, value: bytes) -> None:
    """Store (or overwrite in place) the secret. 0600 / owner-only."""
    (_kc_put if MACOS else _file_put)(service, account, value)


def delete(service: str, account: str) -> bool:
    """Remove the secret; True if something was removed."""
    return (_kc_delete if MACOS else _file_delete)(service, account)
