"""Is a newer robin-mcp out? Check the landing page and warn — no auto-install.

robin-mcp runs from a checkout through a Claude Desktop ``mcpServers`` entry (there is no .mcpb), so there is nothing
to download or install from here. Once a day, in the background, it fetches ``<site>/latest.version``; if that is
newer than this checkout, it warns — on stderr (Claude Desktop's log for the entry), in the server instructions, and
as a short note on a tool result (at most once a day) — telling the owner how to update (re-run the install command,
or ``git pull``). Nothing is installed automatically.

On by default; ``ROBIN_MCP_CHECK_UPDATES=false`` turns it off. Mirrors outlook-okta's config-file-mode update
warning (outlook_okta/updates.py), trimmed to the warn-only path.
"""
from __future__ import annotations

import json
import os
import re
import sys
import threading
import time
import urllib.request
from collections.abc import Callable
from pathlib import Path

from . import config

SITE = "https://wpp-jamie-mills.github.io/robin-mcp-site"
ENV_CHECK = "ROBIN_MCP_CHECK_UPDATES"
CHECK_EVERY_S = 24 * 3600
NOTE_EVERY_S = 24 * 3600
TIMEOUT_S = 5
RELEASE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")
PROJECT = Path(__file__).resolve().parents[1]
_TRUE = {"1", "true", "yes", "on"}


def enabled() -> bool:
    """On by default; ROBIN_MCP_CHECK_UPDATES=false/0/no/off turns it off."""
    value = (config.get(ENV_CHECK, "") or "").strip().lower()
    return value not in {"0", "false", "no", "off"}


def installed_version() -> str:
    try:
        return json.loads((PROJECT / "pyproject.toml").read_text().split("version = ", 1)[1].split("\n", 1)[0])
    except Exception:  # noqa: BLE001 - fall back to the package metadata
        try:
            from importlib.metadata import version

            return version("robin-mcp")
        except Exception:  # noqa: BLE001
            return "0.0.0"


def newer(latest: str, installed: str) -> bool:
    if not RELEASE.match(latest or ""):
        return False
    try:
        return tuple(int(p) for p in latest.split(".")) > tuple(int(p) for p in installed.split("."))
    except ValueError:
        return True


def _cache_dir() -> Path:
    base = Path.home() / "Library" / "Caches" if sys.platform == "darwin" else \
        Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")
    return base / "robin-mcp"


def _fetch(url: str, limit: int = 64) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "robin-mcp-update-check"})
    with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
        return resp.read(limit + 1)[:limit]


class Updates:
    """Warn-only update check for one server process. Outside effects are injectable for tests."""

    def __init__(self, *, site: str = SITE, installed: str | None = None, folder: Path | None = None,
                 fetch: Callable[[str, int], bytes] = _fetch, now: Callable[[], float] = time.time) -> None:
        self.site = site.rstrip("/")
        self.installed = installed or installed_version()
        self.folder = folder or _cache_dir()
        self._fetch, self._now = fetch, now
        self._lock = threading.Lock()
        self._noted_at = 0.0
        self._warned = False

    @property
    def _path(self) -> Path:
        return self.folder / "update-check.json"

    def _load(self) -> dict:
        try:
            data = json.loads(self._path.read_text())
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def _save(self, data: dict) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data))
        tmp.replace(self._path)

    def status(self, force: bool = False) -> dict:
        with self._lock:
            data = self._load()
            due = force or self._now() - float(data.get("checked_at") or 0) >= CHECK_EVERY_S
            if due:
                data["checked_at"] = self._now()
                try:
                    latest = self._fetch(f"{self.site}/latest.version", 64).decode().strip()
                    if not RELEASE.match(latest):
                        raise ValueError("latest.version is not a release version")
                    data["latest"] = latest
                    data.pop("error", None)
                except Exception as exc:  # noqa: BLE001 - offline/blocked/bad answer: try again tomorrow
                    data["error"] = f"{type(exc).__name__}: {exc}"[:200]
                self._save(data)
            latest = str(data.get("latest") or "")
            return {"state": "available" if newer(latest, self.installed) else "up_to_date",
                    "installed": self.installed, "latest": latest or None, "site": self.site}

    def available(self) -> str | None:
        s = self.status(force=False)
        return s["latest"] if s["state"] == "available" else None

    def source_warning(self) -> str:
        latest = self.available()
        if not latest:
            return ""
        return (f"A newer robin-mcp is released (version {latest}; this checkout at {PROJECT} is {self.installed}). "
                f"Update by re-running the install command (see {self.site}) or `git -C {PROJECT} pull --ff-only`, "
                "then quit and reopen Claude Desktop.")

    def warn(self, stream=None) -> str:
        message = self.source_warning()
        with self._lock:
            if not message or self._warned:
                return message
            self._warned = True
        print(f"robin-mcp: {message}", file=stream or sys.stderr, flush=True)
        return message

    def warn_in_background(self, stream=None) -> None:
        self.warn(stream)

        def check_then_warn() -> None:
            self.status()
            self.warn(stream)

        threading.Thread(target=check_then_warn, daemon=True, name="robin-update-check").start()

    def source_note(self) -> str:
        message = self.source_warning()
        if not message or self._now() - self._noted_at < NOTE_EVERY_S:
            return ""
        self._noted_at = self._now()
        return f"[Update: {message} Tell the owner; don't run anything yourself.]"
