"""Command line for robin-mcp: sign in, check status, configure, or run the MCP server.

  robin-mcp login [--force]      sign in to Robin in the browser (or refresh); store the token in the Keychain
  robin-mcp status               show sign-in status and configuration (no secrets)
  robin-mcp logout               forget the stored token
  robin-mcp config set KEY VALUE set a config value (org, service, allow_writes, default_location, default_level, approvals)
  robin-mcp config show          show the resolved configuration
  robin-mcp mcp                  run the stdio MCP server (for Claude Desktop / Claude Code)
"""
from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Callable

from . import auth, config

_CONFIG_KEYS = {
    "org": "ROBIN_MCP_ORG",
    "service": "ROBIN_MCP_SERVICE",
    "allow_writes": "ROBIN_MCP_ALLOW_WRITES",
    "default_location": "ROBIN_MCP_DEFAULT_LOCATION",
    "default_level": "ROBIN_MCP_DEFAULT_LEVEL",
    "approvals": "ROBIN_MCP_APPROVALS",
    "check_updates": "ROBIN_MCP_CHECK_UPDATES",
}


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="robin-mcp", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", metavar="{login,status,logout,config,mcp}")
    lg = sub.add_parser("login", help="sign in to Robin (browser) or refresh the token")
    lg.add_argument("--force", action="store_true", help="ignore the saved token and sign in again")
    sub.add_parser("status", help="show sign-in status and configuration")
    sub.add_parser("logout", help="forget the stored token")
    cfg = sub.add_parser("config", help="get or set configuration")
    cfgsub = cfg.add_subparsers(dest="config_cmd", metavar="{set,show}")
    st = cfgsub.add_parser("set", help="set a config value")
    st.add_argument("key", choices=sorted(_CONFIG_KEYS))
    st.add_argument("value")
    cfgsub.add_parser("show", help="show the resolved configuration")
    sub.add_parser("mcp", help="run the stdio MCP server")
    return ap


def cmd_login(args, out, err) -> int:
    try:
        auth.access_token(force_login=args.force, wait=True)
    except auth.AuthError as exc:
        err.write(f"error: {exc}\n")
        return 1
    who = auth.signed_in_as() or "your Robin account"
    out.write(f"Signed in as {who}.\n")
    return 0


def cmd_status(args, out, err) -> int:
    out.write(json.dumps({"auth": auth.status(), "config": {
        "org": config.org(), "service": config.service(), "allow_writes": config.allow_writes(),
        "default_location": config.default_location(), "default_level": config.default_level(),
        "config_file": str(config.write_path()),
    }}, indent=2) + "\n")
    return 0


def cmd_logout(args, out, err) -> int:
    result = auth.sign_out()
    out.write("Signed out: removed the stored token.\n" if result["removed"] else "Nothing was stored.\n")
    return 0


def cmd_config(args, out, err) -> int:
    if args.config_cmd == "set":
        config.set_values(**{_CONFIG_KEYS[args.key]: args.value})
        out.write(f"Set {args.key} = {args.value} in {config.write_path()}.\n")
        return 0
    out.write(json.dumps({k: config.get(env) for k, env in _CONFIG_KEYS.items()}, indent=2) + "\n")
    return 0


def main(argv: list[str] | None = None, *, out=sys.stdout, err=sys.stderr) -> int:
    args = build_parser().parse_args(argv)
    if args.cmd == "mcp":
        from .mcp_server import main as mcp_main

        mcp_main()  # stdout belongs to the MCP protocol from here on
        return 0
    handlers: dict[str, Callable] = {
        "login": cmd_login, "status": cmd_status, "logout": cmd_logout, "config": cmd_config,
    }
    handler = handlers.get(args.cmd)
    if handler is None:
        build_parser().print_help(err)
        return 2
    return handler(args, out, err)


if __name__ == "__main__":
    sys.exit(main())
