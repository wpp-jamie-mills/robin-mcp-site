"""Stdio MCP server exposing the Robin tools for Claude Desktop and Claude Code.

Read tools are always registered; the write tools (robin_book_room, robin_cancel_booking, robin_add_room,
robin_cancel_room) only when writes are on (``ROBIN_MCP_ALLOW_WRITES``, default on). book_room and cancel_booking go
direct to Robin's REST API; add_room/cancel_room proxy Robin's hosted MCP. The access token stays in this process; tools return
results, never the token. The clients are built on the first tool call, so listing tools never triggers a sign-in.

Claude Desktop runs robin-mcp as a plain ``mcpServers`` entry (bin/robin-mcp sets ``$MCP_RUN_MODE=config``), not a
packaged extension, so Desktop does NOT gate the write tools and has no update channel or settings form. The server
supplies those itself in config-file mode:
  - Sign-in card (sign_in_card.html): when a tool needs a sign-in, robin_sign_in opens the browser and shows a card.
  - Approval card (approval_card.html): each booking/cancel waits for the owner (approvals.py), routed card →
    elicitation → chat (``ROBIN_MCP_APPROVALS``; default chat = the model confirms in the chat).
  - Settings card (settings_card.html): robin_settings shows and changes this entry's settings (settings.py).
  - Update warning (updates.py): once a day it warns, on stderr / in a tool note / in the instructions, that a newer
    robin-mcp is out and how to update the checkout. Nothing is downloaded or installed automatically.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from pathlib import Path

import anyio.from_thread
from mcp.server.apps import Apps, client_supports_apps
from mcp.server.mcpserver import Context, MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.types import CallToolResult, TextContent, ToolAnnotations

from . import approvals, auth, config, rooms, settings, tools, updates
from .client import RobinClient, RobinError
from .official_mcp import OfficialMcp, OfficialMcpError

READ_ONLY = ToolAnnotations(read_only_hint=True, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
BOOKS = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=False, open_world_hint=True)
CANCELS = ToolAnnotations(read_only_hint=False, destructive_hint=True, idempotent_hint=True, open_world_hint=False)
SIGN_IN = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
APPROVE_ACTION = ToolAnnotations(read_only_hint=False, destructive_hint=True, idempotent_hint=False, open_world_hint=True)
DECLINE_ACTION = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=True, open_world_hint=False)
SAVE_SETTINGS = ToolAnnotations(read_only_hint=False, destructive_hint=False, idempotent_hint=True, open_world_hint=False)


def _card_uri(name: str, path: Path) -> str:
    return f"ui://robin-mcp/{name}-{hashlib.sha256(path.read_bytes()).hexdigest()[:12]}.html"


CARD_HTML = Path(__file__).with_name("sign_in_card.html")
CARD_URI = _card_uri("sign-in", CARD_HTML)
APPROVAL_CARD_HTML = Path(__file__).with_name("approval_card.html")
APPROVAL_CARD_URI = _card_uri("approve", APPROVAL_CARD_HTML)
SETTINGS_CARD_HTML = Path(__file__).with_name("settings_card.html")
SETTINGS_CARD_URI = _card_uri("settings", SETTINGS_CARD_HTML)

SIGN_IN_TOOLS = {
    "robin_sign_in": "Start (or show) the Robin sign-in when a tool says sign-in is needed. Opens a Robin sign-in "
                     "page in the browser (click Allow) and shows a card with a live status; also returns the "
                     "instructions as text.",
    "robin_sign_in_status": "Where the Robin sign-in stands: pending, signed_in, failed or idle. Used by the card.",
    "robin_sign_out": "Sign out of Robin: delete the saved token so the next request asks you to sign in again. "
                      "Use only when asked.",
}
APPROVAL_TOOLS = {
    "approve_action": "Do what the approval card shows, after the owner clicked Approve. Used only by the card.",
    "decline_action": "Forget what the approval card shows, after the owner clicked Decline. Used only by the card.",
}
SETTINGS_TOOLS = {
    "robin_settings": "Show the owner this connection's settings (Robin org, booking tools, default building, "
                      "approvals, update check) on a card where they can change them. Changes apply when Claude "
                      "Desktop restarts.",
    "save_settings": "Save the settings the owner changed on the settings card. Used only by the card.",
    "robin_settings_levels": "List a building's floors for the settings card's floor dropdown. Used only by the card.",
}
WAITING = ("Nothing has been done yet: the owner has an approval card showing exactly what this will do ({title}), "
           "with Approve and Decline. End your turn and let them answer on the card; its outcome reaches you with "
           "their next message. Don't call this or another tool to do the same thing, and don't ask again in chat.")
DECLINED = "The owner declined ({title}). Nothing was done; don't do it unless they ask again."
APPROVALS_GUIDE = ("\n\nWhen writes are on, the owner approves each booking/cancel. By default the model confirms it "
                   "in the chat before calling the tool. If a write tool answers that it is waiting for the owner "
                   "(an approval card), end your turn; its outcome arrives with their next message.")


def _describe_sign_in(status: dict) -> str:
    state = status.get("state")
    if state == "pending":
        mins = max(1, (status.get("expires_in_s") or 0) // 60)
        return (f"Sign-in needed. A Robin sign-in page opened in your browser — click Allow (sign in to "
                f"Robin/Okta if asked). If it didn't open: {status.get('url')}  You have about {mins} minutes; "
                "when done, the card tells me and I'll carry on.")
    if state == "signed_in":
        return f"Signed in to Robin{(' as ' + status['user']) if status.get('user') else ''}. Carrying on."
    if state == "failed":
        return f"Sign-in failed: {status.get('error')}. Ask me to sign in again."
    if state == "signed_out":
        return "Signed out of Robin: the saved token was removed." if status.get("removed") else "Nothing was stored."
    return "No sign-in in progress."


class AuthSignIn:
    def begin(self) -> dict:
        return auth.begin_sign_in()

    def status(self) -> dict:
        return auth.sign_in_status()

    def end(self) -> dict:
        return auth.sign_out()


def default_client() -> RobinClient:
    cache = auth.TokenCache()
    org = config.org() or auth.load_record().get("org_id") or ""
    client = RobinClient(cache, org)
    if not client.org:
        orgs = client.rest("GET", "/me/organizations")
        if isinstance(orgs, list) and orgs:
            client.org = str(orgs[0].get("id") or "")
    return client


def default_official() -> OfficialMcp:
    return OfficialMcp(auth.TokenCache())


def build_server(make_client: Callable[[], RobinClient] = default_client,
                 allow_writes: bool | None = None,
                 sign_in: AuthSignIn | None = None,
                 make_official: Callable[[], OfficialMcp] = default_official,
                 updates_obj: updates.Updates | None = None) -> MCPServer:
    allow_writes = config.allow_writes() if allow_writes is None else allow_writes
    sign_in = sign_in or AuthSignIn()
    source_mode = config.config_file_mode()
    upd = updates_obj
    if upd is None and source_mode and updates.enabled():
        upd = updates.Updates()
        upd.warn_in_background()
    # Each booking/cancel waits for the owner only when there is a card/dialog route (approvals=auto). Default chat
    # means the model confirms in the chat, so no server-side gating object is needed.
    pending = approvals.Approvals() if (source_mode and allow_writes and approvals.cap() != "chat") else None
    settings_tokens = approvals.Approvals(folder=approvals._data_dir() / "settings-tokens") if source_mode else None

    holder: list[RobinClient] = []
    official_holder: list[OfficialMcp] = []

    def client() -> RobinClient:
        if not holder:
            holder.append(make_client())
        return holder[0]

    def official() -> OfficialMcp:
        if not official_holder:
            official_holder.append(make_official())
        return official_holder[0]

    def note() -> str:
        try:
            return upd.source_note() if upd else ""
        except Exception:  # noqa: BLE001 - the update note must never cost the owner their answer
            return ""

    def with_note(out: str) -> str:
        n = note()
        return f"{out}\n\n{n}" if n else out

    def call(name: str, /, **inp) -> str:
        inp = {k: v for k, v in inp.items() if v is not None}
        try:
            return with_note(json.dumps(tools.run_tool(client(), name, inp), ensure_ascii=False))
        except auth.SignInRequired as exc:
            raise ToolError(f"{exc}  (call robin_sign_in to show the sign-in card.)") from exc
        except RobinError as exc:
            extra = f" (missing scope: {exc.scope})" if exc.scope else ""
            raise ToolError(f"Robin API error: {exc}{extra}") from exc
        except Exception as exc:
            raise ToolError(f"{type(exc).__name__}: {exc}") from exc

    def call_official(name: str, /, **inp) -> str:
        inp = {k: v for k, v in inp.items() if v is not None}
        try:
            return with_note(json.dumps(official().call_tool(name, inp), ensure_ascii=False))
        except auth.SignInRequired as exc:
            raise ToolError(f"{exc}  (call robin_sign_in to show the sign-in card.)") from exc
        except OfficialMcpError as exc:
            raise ToolError(f"Robin error: {exc}") from exc
        except Exception as exc:
            raise ToolError(f"{type(exc).__name__}: {exc}") from exc

    def run_write(tool: str, inp: dict):
        """Execute a write against the right backend (direct REST or the hosted-MCP proxy)."""
        if tool in ("robin_book_room", "robin_cancel_booking"):
            return tools.run_tool(client(), tool, inp)
        if tool == "robin_add_room":
            return official().call_tool("book_space", {"eventId": str(inp["event_id"]), "spaceId": inp["space_id"]})
        if tool == "robin_cancel_room":
            return official().call_tool("remove_space", {"eventId": str(inp["event_id"]), "spaceId": inp["space_id"]})
        raise KeyError(tool)

    def ask_owner(tool: str, inp: dict, ctx: Context | None):
        caps = ctx.client_capabilities if ctx is not None else None
        can_card = ctx is not None and client_supports_apps(ctx)
        can_elicit = (ctx is not None and approvals.elicit_form_supported(caps)
                      and getattr(ctx.session, "can_send_request", False))
        way = approvals.route(can_card, can_elicit)
        if way == "chat":
            return None
        preview = approvals.build_preview(tool, inp)
        if way == "card":
            token = pending.hold(tool, inp, preview)
            return CallToolResult(content=[TextContent(type="text", text=WAITING.format(title=preview["title"]))],
                                  structured_content={"state": "pending", **preview, "token": token,
                                                      "expires_in_s": approvals.TOKEN_TTL_S},
                                  meta={approvals.META_KEY: {"token": token}})
        answer = anyio.from_thread.run(ctx.elicit, approvals.as_text(preview), approvals.dialog_schema())
        if answer.action != "accept" or not getattr(answer.data, "approve", False):
            return DECLINED.format(title=preview["title"])
        return None

    def call_write(tool: str, inp: dict, ctx: Context | None):
        inp = {k: v for k, v in inp.items() if v is not None}
        try:
            if pending is not None and tool in approvals.NEEDS_APPROVAL:
                decided = ask_owner(tool, inp, ctx)
                if decided is not None:
                    return decided  # a card (CallToolResult) or a declined message (str)
            return with_note(json.dumps(run_write(tool, inp), ensure_ascii=False))
        except auth.SignInRequired as exc:
            raise ToolError(f"{exc}  (call robin_sign_in to show the sign-in card.)") from exc
        except (RobinError, OfficialMcpError) as exc:
            raise ToolError(f"Robin error: {exc}") from exc
        except Exception as exc:
            raise ToolError(f"{type(exc).__name__}: {exc}") from exc

    apps = Apps()

    # ---- sign-in card ----
    def as_result(status: dict) -> CallToolResult:
        return CallToolResult(content=[TextContent(type="text", text=_describe_sign_in(status))],
                              structured_content={"service": "Robin", "client_name": "robin-mcp", **status})

    @apps.tool(resource_uri=CARD_URI, name="robin_sign_in", description=SIGN_IN_TOOLS["robin_sign_in"],
               annotations=SIGN_IN)
    def robin_sign_in() -> CallToolResult:
        return as_result(_guard(sign_in.begin))

    @apps.tool(resource_uri=CARD_URI, visibility=["app"], name="robin_sign_in_status",
               description=SIGN_IN_TOOLS["robin_sign_in_status"], annotations=READ_ONLY)
    def robin_sign_in_status() -> CallToolResult:
        return as_result(_guard(sign_in.status))

    apps.add_html_resource(CARD_URI, CARD_HTML.read_text(), name="Robin sign-in",
                           description="Shows the Robin sign-in status")

    # ---- approval card (config-file mode, approvals=auto) ----
    def approval_result(status: dict) -> CallToolResult:
        text = {"done": f"Done: {status.get('result', '')}", "declined": "Declined; nothing was done."}.get(
            status.get("state"), f"Nothing was done: {status.get('error', '')}")
        return CallToolResult(content=[TextContent(type="text", text=text)], structured_content=status)

    if pending is not None:
        @apps.tool(resource_uri=APPROVAL_CARD_URI, visibility=["app"], name="approve_action",
                   description=APPROVAL_TOOLS["approve_action"], annotations=APPROVE_ACTION)
        def approve_action(token: str) -> CallToolResult:
            try:
                held = pending.take(token)
            except approvals.ApprovalError as exc:
                return approval_result({"state": "expired", "error": str(exc)})
            try:
                result = run_write(held.tool, held.inp)
            except Exception as exc:  # noqa: BLE001 - shown on the card
                return approval_result({**held.preview, "state": "failed", "error": f"{type(exc).__name__}: {exc}"})
            return approval_result({**held.preview, "state": "done", "result": approvals.summarise_result(result)})

        @apps.tool(resource_uri=APPROVAL_CARD_URI, visibility=["app"], name="decline_action",
                   description=APPROVAL_TOOLS["decline_action"], annotations=DECLINE_ACTION)
        def decline_action(token: str) -> CallToolResult:
            held = pending.drop(token)
            if held is None:
                return approval_result({"state": "expired", "error": approvals.EXPIRED})
            return approval_result({**held.preview, "state": "declined"})

        apps.add_html_resource(APPROVAL_CARD_URI, APPROVAL_CARD_HTML.read_text(), name="Approval card",
                               description="Shows exactly what a booking or cancellation will do, with Approve and Decline")

    # ---- settings card (config-file mode) ----
    def building_options():
        """Live buildings for the settings card, or None when they can't be fetched (e.g. not signed in)."""
        try:
            return rooms.locations(client())
        except Exception:  # noqa: BLE001 - the card falls back to text fields; it must never crash
            return None

    def level_options(location_id):
        """A building's floors for the settings card; [] if none or it can't be fetched."""
        try:
            return rooms.levels(client(), location_id) if location_id else []
        except Exception:  # noqa: BLE001
            return []

    if source_mode:
        _add_settings_card(apps, settings_tokens, building_options, level_options)

    guide = tools.INSTRUCTIONS + (APPROVALS_GUIDE if allow_writes else "")
    if upd:
        waiting = upd.available()
        if waiting:
            guide += (f"\n\nAn update to robin-mcp is available (version {waiting}; this is {upd.installed}). Tell the "
                      "owner once, early in the conversation; don't run anything yourself.")
    server = MCPServer("robin-mcp", instructions=guide, extensions=[apps])

    def robin_sign_out() -> str:
        holder.clear()
        official_holder.clear()
        return _describe_sign_in(_guard(sign_in.end))

    def robin_auth_status() -> str:
        """Whether a Robin session is active, the org, scopes and token expiry. No secrets."""
        return with_note(json.dumps(auth.status(), ensure_ascii=False))

    server.add_tool(robin_sign_out, description=SIGN_IN_TOOLS["robin_sign_out"], annotations=SIGN_IN)
    server.add_tool(robin_auth_status, description=robin_auth_status.__doc__, annotations=READ_ONLY)

    # ---- read tools ----
    def robin_whoami() -> str:
        return call("robin_whoami")

    def robin_locations() -> str:
        return call("robin_locations")

    def robin_levels(location_id: int | str) -> str:
        return call("robin_levels", location_id=location_id)

    def robin_find_rooms(start: str, end: str, location_id: int | str | None = None,
                         level_id: int | str | None = None, min_capacity: int | None = None,
                         time_zone: str | None = None, include_unbookable: bool = False) -> str:
        # When the search names neither a building nor a floor, fall back to the configured defaults
        # (ROBIN_MCP_DEFAULT_LOCATION / ROBIN_MCP_DEFAULT_LEVEL) so a bare "find a room at 12:00" works.
        if location_id is None and level_id is None:
            location_id = config.default_location()
            level_id = config.default_level()
        return call("robin_find_rooms", start=start, end=end, location_id=location_id, level_id=level_id,
                    min_capacity=min_capacity, time_zone=time_zone, include_unbookable=include_unbookable)

    def robin_room_details(space_id: int | str) -> str:
        return call("robin_room_details", space_id=space_id)

    def robin_room_schedule(space_id: int | str, after: str, before: str) -> str:
        return call("robin_room_schedule", space_id=space_id, after=after, before=before)

    def robin_my_bookings(after: str, before: str, limit: int = 50) -> str:
        return call("robin_my_bookings", after=after, before=before, limit=limit)

    def robin_find_people(query: str) -> str:
        return call("robin_find_people", query=query)

    def robin_person(user_id: int | str) -> str:
        return call("robin_person", user_id=user_id)

    def robin_working_hours() -> str:
        return call("robin_working_hours")

    def robin_weekly_schedule(location_id: int | str, user_id: int | str | None = None) -> str:
        return call("robin_weekly_schedule", location_id=location_id, user_id=user_id)

    def robin_notification_settings() -> str:
        return call("robin_notification_settings")

    def robin_calendar(date: str, end_date: str | None = None, time_zone: str | None = None,
                       with_space: bool | None = None) -> str:
        """List your calendar meetings for a date (or range), optionally only those that hold a room."""
        return call_official("list_calendar_events", date=date, endDate=end_date, timeZone=time_zone,
                             withSpace=with_space)

    def robin_suggest_rooms(event_id: str | None = None, capacity: int | None = None,
                            location_id: int | str | None = None, time_zone: str | None = None) -> str:
        """Suggest bookable rooms for one of your meetings (event_id) or by capacity/building."""
        return call_official("suggest_spaces", eventId=event_id, capacity=capacity, locationId=location_id,
                             timeZone=time_zone)

    # ---- write tools (ctx is injected by the SDK, not in the schema; used for the approval route) ----
    def robin_book_room(space_id: int | str, start: str, end: str, title: str,
                        invitees: list[str] | None = None, description: str = "", private: bool = False,
                        time_zone: str | None = None, allow_long: bool = False, ctx: Context | None = None):
        return call_write("robin_book_room", {"space_id": space_id, "start": start, "end": end, "title": title,
                                              "invitees": invitees, "description": description, "private": private,
                                              "time_zone": time_zone, "allow_long": allow_long}, ctx)

    def robin_cancel_booking(event_id: str, ctx: Context | None = None):
        """Cancel a booking you made and free its room. event_id from robin_my_bookings or robin_book_room's result.
        This cancels the WHOLE booking (unlike robin_cancel_room, which only takes a room off a meeting that stays),
        so it's how to undo a standalone robin_book_room booking. If others were invited, they're told it's cancelled."""
        return call_write("robin_cancel_booking", {"event_id": event_id}, ctx)

    def robin_add_room(event_id: str, space_id: int | str, ctx: Context | None = None):
        """Add (book) a room onto an existing calendar meeting of yours. event_id from robin_calendar; space_id
        from robin_find_rooms/robin_suggest_rooms."""
        return call_write("robin_add_room", {"event_id": event_id, "space_id": space_id}, ctx)

    def robin_cancel_room(event_id: str, space_id: int | str, ctx: Context | None = None):
        """Remove (cancel) a room from a meeting — frees the room, keeps the meeting. event_id from robin_calendar
        (with_space=true) or robin_add_room; space_id is the room to remove. Note: a room booked standalone in Robin
        IS its own meeting and can't be removed this way — cancel it in the Robin app."""
        return call_write("robin_cancel_room", {"event_id": event_id, "space_id": space_id}, ctx)

    read_fns = [robin_whoami, robin_locations, robin_levels, robin_find_rooms, robin_room_details,
                robin_room_schedule, robin_my_bookings, robin_find_people, robin_person, robin_working_hours,
                robin_weekly_schedule, robin_notification_settings, robin_calendar, robin_suggest_rooms]
    for fn in read_fns:
        desc = tools.BY_NAME[fn.__name__].description if fn.__name__ in tools.BY_NAME else fn.__doc__
        server.add_tool(fn, name=fn.__name__, description=desc, annotations=READ_ONLY, structured_output=False)
    if allow_writes:
        meta = {"ui": {"resourceUri": APPROVAL_CARD_URI}} if pending is not None else None
        server.add_tool(robin_book_room, name="robin_book_room",
                        description=tools.BY_NAME["robin_book_room"].description, annotations=BOOKS,
                        structured_output=False, meta=meta)
        server.add_tool(robin_cancel_booking, name="robin_cancel_booking",
                        description=tools.BY_NAME["robin_cancel_booking"].description, annotations=CANCELS,
                        structured_output=False, meta=meta)
        server.add_tool(robin_add_room, name="robin_add_room", description=robin_add_room.__doc__,
                        annotations=BOOKS, structured_output=False, meta=meta)
        server.add_tool(robin_cancel_room, name="robin_cancel_room", description=robin_cancel_room.__doc__,
                        annotations=CANCELS, structured_output=False, meta=meta)
    return server


# --------------------------------------------------------------------------- settings card


def _floor_label(name) -> str:
    """A friendly floor name: numeric names become 'Floor 8'; words like 'Ground Floor' stay as-is."""
    s = str(name if name is not None else "").strip()
    return f"Floor {s}" if s.isdigit() else (s or "(floor)")


def _level_option_list(levels: list | None, location_id) -> list[dict]:
    """Floor dropdown options for one building (with a leading 'any floor')."""
    out = [{"value": "", "label": "(any floor)"}]
    for lv in levels or []:
        out.append({"value": str(lv["level_id"]), "label": _floor_label(lv.get("name")),
                    "location": str(location_id or "")})
    return out


def _settings_state(token: str = "", choices: dict | None = None, **extra) -> dict:
    eff = settings.effective()
    fields = []
    for f in settings.FIELDS:
        e = eff[f.name]
        row = {"name": f.name, "label": f.label, "kind": f.kind, "value": e["value"], "source": e["source"],
               "env": f.env, "help": f.help}
        if f.options:
            row["options"] = [{"value": v, "label": label} for v, label in f.options]
        if choices and f.name in choices:  # live building/floor dropdowns (when signed in on a card client)
            row["kind"] = "choice"
            row["value"] = "" if e["value"] in (None, "") else str(e["value"])
            row["options"] = choices[f.name]["options"]
            if choices[f.name].get("depends_on"):
                row["depends_on"] = choices[f.name]["depends_on"]
        fields.append(row)
    return {"state": "shown", "fields": fields, "file": str(config.write_path()), "token": token, **extra}


def _describe_settings(state: dict) -> str:
    rows = [f"{f['label']}: {f['value'] if f['value'] not in ('', None) else '(not set)'}"
            + (" (set in the Claude Desktop entry)" if f["source"] == "entry" else "") for f in state["fields"]]
    head = ("The owner has a settings card to change these; changes apply when Claude Desktop restarts."
            if state.get("token") else
            f"This client can't show the settings card: change these in {state['file']} or the entry's env, "
            "then restart Claude Desktop.")
    return head + "\n" + "\n".join(rows)


def _add_settings_card(apps: Apps, tokens, buildings=None, levels=None) -> None:
    def result(state: dict, text: str | None = None) -> CallToolResult:
        public = {k: v for k, v in state.items() if k != "token"}
        return CallToolResult(content=[TextContent(type="text", text=text or _describe_settings(state))],
                              structured_content=state if state.get("token") else public)

    def live_choices() -> dict | None:
        """Live building + current-building floor dropdowns, or None when buildings can't be fetched."""
        bopts = buildings() if buildings else None
        if bopts is None:
            return None
        loc = config.default_location()
        lopts = (levels(loc) if levels else []) or []
        return {
            "default_location": {"options": [{"value": "", "label": "(no default — ask each time)"}]
                                 + [{"value": str(b["location_id"]), "label": b["name"]} for b in bopts]},
            "default_level": {"depends_on": "default_location", "options": _level_option_list(lopts, loc)},
        }

    @apps.tool(resource_uri=SETTINGS_CARD_URI, name="robin_settings", description=SETTINGS_TOOLS["robin_settings"],
               annotations=READ_ONLY)
    def robin_settings(ctx: Context) -> CallToolResult:
        supports = client_supports_apps(ctx)
        token = tokens.hold("settings", {}, {}) if supports else ""
        return result(_settings_state(token, live_choices() if supports else None))

    @apps.tool(resource_uri=SETTINGS_CARD_URI, visibility=["app"], name="robin_settings_levels",
               description=SETTINGS_TOOLS["robin_settings_levels"], annotations=READ_ONLY)
    def robin_settings_levels(location_id: str = "") -> CallToolResult:
        loc = str(location_id or "")
        opts = _level_option_list(levels(loc) if (levels and loc) else [], loc)
        return CallToolResult(content=[TextContent(type="text", text="")],
                              structured_content={"location_id": loc, "options": opts})

    @apps.tool(resource_uri=SETTINGS_CARD_URI, visibility=["app"], name="save_settings",
               description=SETTINGS_TOOLS["save_settings"], annotations=SAVE_SETTINGS)
    def save_settings(token: str, changes: dict) -> CallToolResult:
        try:
            tokens.peek(token)
            settings.save(changes)
            tokens.take(token)
        except (approvals.ApprovalError, ValueError) as exc:
            keep = token if not isinstance(exc, approvals.ApprovalError) else ""
            return result({**_settings_state(keep), "state": "failed", "error": str(exc)}, f"Not saved: {exc}")
        state = _settings_state(tokens.hold("settings", {}, {}), saved=sorted(changes))
        return result({**state, "state": "saved"},
                      f"Saved {', '.join(sorted(changes))}. They apply when Claude Desktop restarts.")

    apps.add_html_resource(SETTINGS_CARD_URI, SETTINGS_CARD_HTML.read_text(), name="Settings card",
                           description="Shows and changes this connection's settings")


def _guard(fn: Callable[[], dict]) -> dict:
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001 - report to the card/model, never crash the connection
        return {"state": "failed", "error": f"{type(exc).__name__}: {exc}"}


def main() -> None:
    build_server().run("stdio")


if __name__ == "__main__":
    main()
