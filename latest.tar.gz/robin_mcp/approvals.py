"""The owner's approval before a write, for a Claude Desktop ``mcpServers`` entry (config-file mode).

Claude Desktop gates each write tool for a packaged extension, but NOT for a plain ``mcpServers`` entry — which is
all robin-mcp ever is. So each state-changing tool (book a room, add a room to a meeting, remove a room) waits for
the owner, in the best way the client offers:

- card: a client that renders MCP Apps (Claude Desktop) shows the approval card (approval_card.html) with exactly
  what will happen; its Approve/Decline call the app-only tools with a one-time token the model never sees.
- elicitation: a client that can ask the owner itself (Claude Code) shows the same summary in its dialog.
- chat: otherwise the model shows the owner what will happen and waits for a yes in the chat.

Default is ``chat`` (the model confirms in the chat); ``ROBIN_MCP_APPROVALS=auto`` turns on the card/dialog.
Adapted from outlook_okta/approvals.py, trimmed to robin-mcp's three write tools.
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

ROUTE_ENV = "ROBIN_MCP_APPROVALS"
ROUTES = ("card", "elicitation", "chat")  # best first
TOKEN_TTL_S = 900
MAX_PENDING = 50
META_KEY = "robin-mcp/approval"

NEEDS_APPROVAL = frozenset({"robin_book_room", "robin_add_room", "robin_cancel_room", "robin_cancel_booking"})
EXPIRED = "this approval has expired or was already answered; nothing was done. Ask again if you still want it."


class ApprovalError(RuntimeError):
    """The approval can't go ahead; the message says why."""


def _data_dir() -> Path:
    base = os.environ.get("ROBIN_MCP_DATA_DIR")
    if base:
        return Path(base)
    return Path.home() / "Library" / "Application Support" / "robin-mcp" if sys.platform == "darwin" \
        else Path(os.environ.get("XDG_STATE_HOME") or Path.home() / ".local" / "state") / "robin-mcp"


def cap() -> str:
    """The best route allowed: $ROBIN_MCP_APPROVALS, else the entry's settings, else ``chat``. ``auto`` → card."""
    from . import settings

    value = str(settings.value("approvals") or "chat")
    return "card" if value == "auto" else value if value in ROUTES else "chat"


def elicit_form_supported(capabilities: Any) -> bool:
    elicit = getattr(capabilities, "elicitation", None) if capabilities else None
    return elicit is not None and (elicit.form is not None or getattr(elicit, "url", None) is None)


def route(apps: bool, elicit_form: bool) -> str:
    allowed = ROUTES[ROUTES.index(cap()):]
    if "card" in allowed and apps:
        return "card"
    if "elicitation" in allowed and elicit_form:
        return "elicitation"
    return "chat"


# --------------------------------------------------------------------------- pending store (files, multi-process)


@dataclass
class Pending:
    tool: str
    inp: dict
    preview: dict
    expires: float
    extra: dict = field(default_factory=dict)


class Approvals:
    """Writes waiting for approval: one-time tokens as owner-only files that expire. Multi-process safe (Claude
    Desktop can run more than one process per entry), so a token still works once whichever process answers."""

    def __init__(self, folder: Path | None = None, clock: Callable[[], float] = time.time,
                 ttl: float = TOKEN_TTL_S, limit: int = MAX_PENDING) -> None:
        self.folder = Path(folder) if folder else _data_dir() / "approvals"
        self._clock, self._ttl, self._limit = clock, ttl, limit

    def _path(self, token: str) -> Path:
        return self.folder / (hashlib.sha256(str(token or "").encode()).hexdigest()[:40] + ".json")

    def hold(self, tool: str, inp: dict, preview: dict, extra: dict | None = None) -> str:
        self.folder.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.folder, 0o700)
        self._expire()
        token = secrets.token_urlsafe(16)
        record = {"tool": tool, "inp": inp, "preview": preview, "extra": extra or {},
                  "expires": self._clock() + self._ttl}
        path = self._path(token)
        tmp = path.with_suffix(f".tmp-{os.getpid()}")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(record, f, ensure_ascii=False)
        os.replace(tmp, path)
        return token

    def _read(self, path: Path) -> Pending | None:
        try:
            r = json.loads(path.read_text())
        except (OSError, ValueError):
            return None
        if float(r.get("expires") or 0) < self._clock():
            path.unlink(missing_ok=True)
            return None
        return Pending(r["tool"], r["inp"], r["preview"], float(r["expires"]), r.get("extra") or {})

    def peek(self, token: str) -> Pending:
        p = self._read(self._path(token)) if token else None
        if p is None:
            raise ApprovalError(EXPIRED)
        return p

    def take(self, token: str) -> Pending:
        p = self._claim(token)
        if p is None:
            raise ApprovalError(EXPIRED)
        return p

    def drop(self, token: str) -> Pending | None:
        return self._claim(token)

    def _claim(self, token: str) -> Pending | None:
        if not token:
            return None
        path = self._path(token)
        claimed = path.with_suffix(f".taken-{os.getpid()}-{threading.get_ident()}")
        try:
            os.rename(path, claimed)
        except OSError:
            return None
        try:
            return self._read(claimed)
        finally:
            claimed.unlink(missing_ok=True)

    def _expire(self) -> None:
        now = self._clock()
        live = []
        for f in self.folder.glob("*"):
            if f.suffix != ".json":
                if now - f.stat().st_mtime > self._ttl:
                    f.unlink(missing_ok=True)
                continue
            try:
                expires = float(json.loads(f.read_text()).get("expires") or 0)
            except (OSError, ValueError):
                expires = 0
            if expires < now:
                f.unlink(missing_ok=True)
            else:
                live.append((expires, f))
        for _, f in sorted(live)[:max(0, len(live) - self._limit + 1)]:
            f.unlink(missing_ok=True)


# --------------------------------------------------------------------------- previews: what a write will do


def _join(v: Any) -> str:
    if not v:
        return ""
    return v if isinstance(v, str) else ", ".join(str(x) for x in v)


class _Preview:
    def __init__(self, tool: str, title: str, effect: str = "") -> None:
        self.data: dict[str, Any] = {"tool": tool, "title": title, "effect": effect, "fields": [], "text": None,
                                     "items": None, "warnings": [], "choices": [], "ticks": []}

    def field(self, label: str, value: Any) -> _Preview:
        text = _join(value) if isinstance(value, list | tuple) else ("" if value is None else str(value))
        if text != "":
            self.data["fields"].append({"label": label, "value": text})
        return self

    def warn(self, text: str) -> _Preview:
        self.data["warnings"].append(text)
        return self


def build_preview(tool: str, inp: dict) -> dict:
    """What ``tool`` with ``inp`` will do, for the card or dialog (ids/args shown as text; nothing executed)."""
    if tool == "robin_book_room":
        people = list(inp.get("invitees") or [])
        p = _Preview(tool, "Book a room", "Books the room as soon as you approve." if not people
                     else "Books the room and invites people as soon as you approve.")
        p.field("Room (space id)", inp.get("space_id")).field("When", f"{inp.get('start')} to {inp.get('end')}")
        p.field("Title", inp.get("title")).field("Invitees", people).field("Private", "yes" if inp.get("private") else "")
        if people:
            p.warn(f"{len(people)} {'person' if len(people) == 1 else 'people'} will get an invitation.")
    elif tool == "robin_add_room":
        p = _Preview(tool, "Add a room to a meeting", "Adds the room to the meeting as soon as you approve.")
        p.field("Meeting (event id)", inp.get("event_id")).field("Room (space id)", inp.get("space_id"))
    elif tool == "robin_cancel_room":
        p = _Preview(tool, "Remove a room from a meeting", "Frees the room; the meeting itself stays.")
        p.field("Meeting (event id)", inp.get("event_id")).field("Room (space id)", inp.get("space_id"))
    elif tool == "robin_cancel_booking":
        p = _Preview(tool, "Cancel a booking", "Cancels the whole booking and frees the room. This can't be undone.")
        p.field("Booking (event id)", inp.get("event_id"))
        p.warn("The booking is removed; if other people were invited, they're told it's cancelled.")
    else:
        raise ApprovalError(f"{tool} doesn't take an approval")
    return p.data


def as_text(preview: dict, limit: int = 4000) -> str:
    lines = [preview["title"]]
    if preview.get("effect"):
        lines.append(preview["effect"])
    lines += [f"{f['label']}: {f['value']}" for f in preview.get("fields", [])]
    lines += [f"Note: {w}" for w in preview.get("warnings", [])]
    return "\n".join(lines)[:limit]


def dialog_schema() -> type:
    from pydantic import Field, create_model

    return create_model("Approval", approve=(bool, Field(default=False, title="Approve",
                                                        description="Tick to go ahead; leave it to decline.")))


def summarise_result(result: Any, limit: int = 300) -> str:
    text = json.dumps(result, ensure_ascii=False) if not isinstance(result, str) else result
    return text if len(text) <= limit else text[:limit] + "..."
