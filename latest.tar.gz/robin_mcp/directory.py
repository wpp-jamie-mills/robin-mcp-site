"""Me, people, schedule and settings — the read features that work on OAuth (REST + pinned GraphQL)."""
from __future__ import annotations

from .client import RobinClient


def whoami(client: RobinClient) -> dict:
    me = client.rest("GET", "/me") or {}
    orgs = client.rest("GET", f"/users/{me.get('id')}/organizations") if me.get("id") else []
    return {
        "user_id": me.get("id"),
        "name": me.get("name"),
        "email": (me.get("primary_email") or {}).get("email"),
        "time_zone": me.get("time_zone"),
        "organizations": [{"id": o.get("id"), "name": o.get("name"), "slug": o.get("slug")}
                          for o in (orgs if isinstance(orgs, list) else [])],
        "active_org": client.org,
    }


def working_hours(client: RobinClient) -> list[dict]:
    me = client.rest("GET", "/me") or {}
    return me.get("working_hours") or []


def find_people(client: RobinClient, query: str) -> list[dict]:
    data = client.gql("GetUsersByKeyword", {"query": query, "organizationId": client.org})
    rows = data.get("getUsersByKeyword") or []
    return [{"user_id": r.get("id"), "name": r.get("name"),
             "email": (r.get("primaryEmail") or {}).get("email")} for r in rows]


def person(client: RobinClient, user_id) -> dict:
    data = client.rest("GET", f"/users/{user_id}") or {}
    return {
        "user_id": data.get("id"),
        "name": data.get("name"),
        "email": (data.get("primary_email") or {}).get("email"),
        "time_zone": data.get("time_zone"),
        "working_hours": data.get("working_hours") or [],
    }


def weekly_schedule(client: RobinClient, location_id, user_id=None) -> dict:
    uid = str(user_id or (client.rest("GET", "/me") or {}).get("id"))
    data = client.gql("GetWeeklyScheduleForUser", {"userId": uid, "locationId": str(location_id)})
    sched = ((data.get("employeeVisit") or {}).get("getWeeklyScheduleForUser")) or {}
    return {d: sched.get(d) for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")}


def notification_settings(client: RobinClient) -> list[dict]:
    uid = str((client.rest("GET", "/me") or {}).get("id"))
    data = client.gql("GetUserNotificationSettings", {"userId": uid})
    rows = data.get("getUserNotificationSettings") or []
    return [{"name": r.get("name"), "values": r.get("values")} for r in rows]
