"""Settings for a Claude Desktop ``mcpServers`` entry, shown and changed on the settings card.

A packaged extension would get a settings form in Claude Desktop; a plain ``mcpServers`` entry (all robin-mcp ever
is) does not, so the server offers a settings card (robin_settings). It reads and writes the same configuration
config.py uses (env → config.env file → default); a value set in the entry's own ``env`` still wins and can't be
changed on the card. Changes apply when Claude Desktop next starts the server. Mirrors outlook_okta/settings.py,
trimmed to robin-mcp's settings.
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any

from . import config

_TRUE, _FALSE = {"1", "true", "yes", "on"}, {"0", "false", "no", "off"}


@dataclass(frozen=True)
class Field:
    name: str
    label: str
    kind: str  # text | bool | choice
    env: str
    default: Any
    help: str = ""
    options: tuple[tuple[str, str], ...] = ()


FIELDS = (
    Field("org", "Robin organisation (id or slug)", "text", "ROBIN_MCP_ORG", "",
          "Your Robin organisation. Blank: resolved from your account at sign-in."),
    Field("allow_writes", "Enable booking tools", "bool", "ROBIN_MCP_ALLOW_WRITES", True,
          "Book a room, add a room to a meeting, remove a room. On by default."),
    Field("default_location", "Default building (id)", "text", "ROBIN_MCP_DEFAULT_LOCATION", "",
          "A building id that room searches fall back to when you name no building or floor. Optional. "
          "Find ids with robin_locations."),
    Field("default_level", "Default floor (level id)", "text", "ROBIN_MCP_DEFAULT_LEVEL", "",
          "A floor (level) id used with the default building when a search names no building or floor. "
          "Optional. Each room from robin_find_rooms shows its level_id."),
    Field("approvals", "Approve bookings", "choice", "ROBIN_MCP_APPROVALS", "chat",
          "Where you approve a booking/cancel before it happens.",
          (("chat", "In the chat"), ("auto", "On an approval card"))),
    Field("check_updates", "Check for updates", "bool", "ROBIN_MCP_CHECK_UPDATES", True,
          "Once a day, check the landing page for a newer release and warn you."),
)
BY_NAME = {f.name: f for f in FIELDS}


def _env_set(f: Field) -> bool:
    v = os.environ.get(f.env, "")
    return bool(v) and not v.startswith("${")


def _typed(f: Field, raw: Any) -> Any:
    if f.kind == "bool":
        if isinstance(raw, bool):
            return raw
        s = str(raw).strip().lower()
        return s not in _FALSE if f.name == "allow_writes" and s == "" else s in _TRUE
    if f.kind == "choice":
        s = str(raw or "").strip()
        allowed = tuple(v for v, _ in f.options)
        return s if s in allowed else f.default
    return str(raw if raw is not None else "").strip()


def effective() -> dict[str, dict[str, Any]]:
    """Each setting's value and where it comes from (entry env, config file, or default)."""
    file_values = config._file_values()
    out = {}
    for f in FIELDS:
        if _env_set(f):
            out[f.name] = {"value": _typed(f, os.environ[f.env]), "source": "entry"}
        elif f.env in file_values:
            out[f.name] = {"value": _typed(f, file_values[f.env]), "source": "file"}
        else:
            out[f.name] = {"value": f.default, "source": "default"}
    return out


def value(name: str) -> Any:
    return effective()[name]["value"]


def save(changes: dict[str, Any]) -> dict[str, Any]:
    """Persist changed settings to config.env. A setting fixed in the entry's env can't be changed here."""
    to_write = {}
    for name, raw in changes.items():
        f = BY_NAME.get(name)
        if f is None:
            raise ValueError(f"no setting {name!r}")
        if _env_set(f):
            raise ValueError(f"{f.label} is set in the Claude Desktop entry ({f.env}); change it there")
        v = _typed(f, raw)
        to_write[f.env] = "true" if v is True else "false" if v is False else str(v)
    config.set_values(**to_write)
    return {n: value(n) for n in BY_NAME}
