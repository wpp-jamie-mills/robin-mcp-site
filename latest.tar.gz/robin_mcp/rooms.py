"""Meeting-room features over the REST API: find free rooms, room details and schedule, my
bookings, booking a room directly (the thing the official MCP can't do) and cancelling a booking."""
from __future__ import annotations

import datetime as dt

from .client import RobinClient, RobinError

MAX_DURATION_H = 8


# --------------------------------------------------------------------------- helpers


def _space_brief(sp: dict) -> dict:
    return {
        "space_id": sp.get("id"),
        "name": sp.get("name"),
        "capacity": sp.get("capacity"),
        "type": sp.get("type"),
        "location_id": sp.get("location_id"),
        "level_id": sp.get("level_id"),
    }


def _robin_datetime(value: str, tz_name: str | None) -> tuple[str, str]:
    """Return (date_time, time_zone) in the form Robin's event API requires: the local time with a
    numeric offset like ``2026-11-19T10:00:00+0000`` (a ``...Z`` value is rejected). A naive input is
    taken to be in ``tz_name``."""
    try:
        parsed = dt.datetime.fromisoformat(value)
    except ValueError as exc:
        raise RobinError(f"invalid date-time {value!r}: use ISO 8601, e.g. 2026-11-19T10:00:00") from exc
    tz = _zone(tz_name)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=tz or dt.UTC)
    stamp = parsed.strftime("%Y-%m-%dT%H:%M:%S%z")  # e.g. 2026-11-19T10:00:00+0000
    return stamp, (tz_name or _offset_name(parsed))


def _zone(tz_name: str | None):
    if not tz_name:
        return None
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(tz_name)
    except Exception:  # noqa: BLE001 - an unknown zone falls back to the input's own offset
        return None


def _offset_name(d: dt.datetime) -> str:
    return "UTC" if d.utcoffset() in (None, dt.timedelta(0)) else d.strftime("%z")


# --------------------------------------------------------------------------- reads


def locations(client: RobinClient) -> list[dict]:
    data = client.rest("GET", f"/organizations/{client.org}/locations", params={"per_page": 100})
    rows = data if isinstance(data, list) else []
    return [{"location_id": r.get("id"), "name": r.get("name"), "time_zone": r.get("time_zone"),
             "address": r.get("address")} for r in rows]


def building_timezone(client: RobinClient, location_id) -> str | None:
    data = client.rest("GET", f"/locations/{location_id}")
    return (data or {}).get("time_zone") if isinstance(data, dict) else None


def levels(client: RobinClient, location_id) -> list[dict]:
    """A building's floors (levels): id and name, e.g. {'level_id': 125347, 'name': '8'}. Hidden and
    disabled floors are left out. (GET /locations/:id/levels — undocumented but live on the tenant.)"""
    data = client.rest("GET", f"/locations/{location_id}/levels")
    rows = data if isinstance(data, list) else []
    return [{"level_id": r.get("id"), "name": r.get("name"), "location_id": r.get("location_id")}
            for r in rows if not r.get("is_disabled") and not r.get("is_hidden")]


def find_rooms(client: RobinClient, *, start: str, end: str, location_id=None, level_id=None,
               min_capacity: int | None = None, time_zone: str | None = None,
               include_unbookable: bool = False) -> list[dict]:
    if not location_id and not level_id:
        raise RobinError("give a location_id (building) or level_id (floor) to search, or set a default "
                         "building/floor (ROBIN_MCP_DEFAULT_LOCATION / ROBIN_MCP_DEFAULT_LEVEL)")
    tz = time_zone or (building_timezone(client, location_id) if location_id else None)
    scope: dict = {}
    # A level belongs to exactly one building, and Robin's free-busy IGNORES level_ids when location_ids
    # is also present (it returns the whole building), so scope by the level alone when we have one. The
    # location_id is still used above for the building timezone.
    if level_id:
        scope["level_ids"] = [int(level_id)]
    elif location_id:
        scope["location_ids"] = [int(location_id)]
    filters: dict = {"include_unbookable": include_unbookable}
    if min_capacity:
        filters["min_capacity"] = int(min_capacity)
    bounds = {"from": start, "to": end}
    if tz:
        bounds["time_zone"] = tz
    body = {"scope": scope, "filters": filters,
            "view_options": {"bounds": bounds, "prioritization_type": "specific_time"}}
    data = client.rest("POST", "/free-busy/spaces", json_body=body)
    rows = data if isinstance(data, list) else []
    out = []
    for r in rows:
        sp = r.get("space") or {}
        unbookable = r.get("unbookable") or []
        out.append({**_space_brief(sp),
                    "bookable": not unbookable,
                    "unbookable_reasons": [u.get("reason") if isinstance(u, dict) else u for u in unbookable],
                    "availability": r.get("availability")})
    return out


def room_details(client: RobinClient, space_id) -> dict:
    data = client.rest("GET", f"/spaces/{space_id}")
    return data or {}


def room_schedule(client: RobinClient, space_id, *, after: str, before: str) -> list[dict]:
    data = client.rest("GET", f"/spaces/{space_id}/events", params={"after": after, "before": before})
    rows = data if isinstance(data, list) else []
    return [_event_brief(e) for e in rows]


def my_bookings(client: RobinClient, *, after: str, before: str, limit: int = 50) -> list[dict]:
    data = client.rest("GET", "/me/events", params={"after": after, "before": before,
                                                    "include": "space", "per_page": limit})
    rows = data if isinstance(data, list) else []
    return [_event_brief(e) for e in rows]


def _event_brief(e: dict) -> dict:
    return {
        "event_id": e.get("id"),
        "title": e.get("title"),
        "space_id": e.get("space_id"),
        "start": (e.get("start") or {}).get("date_time"),
        "end": (e.get("end") or {}).get("date_time"),
        "time_zone": (e.get("start") or {}).get("time_zone"),
        # Cancellation route: these bookings are real calendar meetings (usually Microsoft 365). This server
        # can't cancel them (Robin won't grant the scope); cancel the meeting in the calendar instead.
        "remote_type": e.get("remote_type"),
        "room_mailbox": e.get("remote_calendar_mailbox_address"),
    }


# --------------------------------------------------------------------------- write: book a room


def book_room(client: RobinClient, *, space_id, start: str, end: str, title: str,
              invitees: list[str] | None = None, description: str = "", private: bool = False,
              time_zone: str | None = None, allow_long: bool = False) -> dict:
    tz = time_zone or building_timezone(client, _space_location(client, space_id))
    start_dt, start_tz = _robin_datetime(start, tz)
    end_dt, end_tz = _robin_datetime(end, tz)
    s_parsed = dt.datetime.fromisoformat(start_dt)
    e_parsed = dt.datetime.fromisoformat(end_dt)
    if e_parsed <= s_parsed:
        raise RobinError("end must be after start")
    if (e_parsed - s_parsed) > dt.timedelta(hours=MAX_DURATION_H) and not allow_long:
        raise RobinError(f"booking longer than {MAX_DURATION_H}h; pass allow_long=true if intended")
    if s_parsed < dt.datetime.now(s_parsed.tzinfo) - dt.timedelta(minutes=1):
        raise RobinError("start time is in the past")
    people = [{"email": a} for a in (invitees or [])]
    body = {
        "title": title, "space_id": int(space_id),
        "start": {"date_time": start_dt, "time_zone": start_tz},
        "end": {"date_time": end_dt, "time_zone": end_tz},
        "is_all_day": False, "creator_is_invitee": True,
        "invitees": people, "invitee_count": len(people) + 1,
        "description": description, "visibility": "private" if private else "default",
        "recurrence": None,
    }
    data = client.rest("POST", f"/spaces/{space_id}/events", json_body=body)
    data = data or {}
    return {
        "event_id": data.get("id"),
        "title": data.get("title"),
        "space_id": data.get("space_id"),
        "start": (data.get("start") or {}).get("date_time"),
        "end": (data.get("end") or {}).get("date_time"),
        "time_zone": (data.get("start") or {}).get("time_zone"),
        "checked_in": bool(data.get("confirmation")),
        "remote_type": data.get("remote_type"),
        "room_mailbox": data.get("remote_calendar_mailbox_address"),
        "note": "Booked. To cancel it later and free the room, call robin_cancel_booking with this event_id.",
    }


def cancel_booking(client: RobinClient, *, event_id) -> dict:
    """Cancel a booking and free its room with ``DELETE /events/{id}``.

    This cancels the whole booking, so it's the way to undo a standalone ``book_room`` booking (which IS its own
    meeting). It works with the scopes robin-mcp already holds (``bookings:write``); Robin does not require the
    ``event:cancel`` scope it refuses self-registered clients. If the booking has other invitees, cancelling it
    tells them, exactly as cancelling the meeting would."""
    eid = str(event_id or "").strip()
    if not eid:
        raise RobinError("event_id is required")
    before: dict = {}
    try:  # details are a nicety for the confirmation; never let a failed lookup block the cancel
        before = client.rest("GET", f"/events/{eid}") or {}
    except RobinError:
        before = {}
    client.rest("DELETE", f"/events/{eid}")
    return {
        "event_id": eid,
        "cancelled": True,
        "title": before.get("title"),
        "space_id": before.get("space_id"),
        "room_mailbox": before.get("remote_calendar_mailbox_address"),
        "note": "Cancelled: the booking is removed and the room is freed.",
    }


def _space_location(client: RobinClient, space_id):
    return (room_details(client, space_id) or {}).get("location_id")
