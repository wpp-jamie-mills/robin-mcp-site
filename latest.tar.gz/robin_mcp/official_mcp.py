"""A small client to Robin's own hosted MCP server (https://mcp.robinpowered.com/mcp).

Some actions a self-registered OAuth client can't do directly against Robin's REST API — notably
attaching a room to an existing meeting (book_space) and removing a room from a meeting
(remove_space, "free the room, keep the meeting") — ARE available through Robin's official MCP
server, which performs them server-side. Robin's MCP accepts our own OAuth access token (same token
as the REST client) as long as it carries the ``bot`` scope (see auth.SCOPES). This module lets
robin-mcp call that server, so the user gets those capabilities through this one MCP without adding
Robin's MCP to their client.

Transport: MCP Streamable HTTP, stateless (the server returns no session id), so each call runs
initialize → initialized → tools/call. Responses may be JSON or a single SSE ``data:`` line.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable

URL = "https://mcp.robinpowered.com/mcp"
HOST = "mcp.robinpowered.com"
UA = "robin-mcp"
TIMEOUT = 60
PROTOCOL = "2026-01-26"


class OfficialMcpError(RuntimeError):
    """A tool call to Robin's MCP failed; the message is Robin's own."""


class OfficialMcp:
    def __init__(self, token_provider: Callable[..., str]) -> None:
        self._token = token_provider

    def _post(self, payload: dict, token: str) -> tuple[int, bytes]:
        if urllib.parse.urlparse(URL).scheme != "https" or urllib.parse.urlparse(URL).hostname != HOST:
            raise OfficialMcpError("refusing request to an unexpected host")
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json",
                   "Accept": "application/json, text/event-stream", "User-Agent": UA}
        req = urllib.request.Request(URL, data=json.dumps(payload).encode(), headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read() or b""

    @staticmethod
    def _parse(raw: bytes):
        body = raw.decode("utf-8", "replace")
        if body.startswith("data:") or "\ndata:" in body:
            for line in body.splitlines():
                if line.startswith("data:"):
                    body = line[5:].strip()
                    break
        try:
            return json.loads(body)
        except ValueError:
            return None

    def call_tool(self, name: str, arguments: dict):
        """Call a tool on Robin's MCP and return its result (parsed JSON, or text). Raises on error.
        Refreshes the token once on an auth failure."""
        for attempt in (0, 1):
            token = self._token(force_refresh=attempt == 1)
            self._post({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                        "params": {"protocolVersion": PROTOCOL, "capabilities": {},
                                   "clientInfo": {"name": "robin-mcp", "version": "0.1"}}}, token)
            self._post({"jsonrpc": "2.0", "method": "notifications/initialized", "params": {}}, token)
            status, raw = self._post({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                                      "params": {"name": name, "arguments": arguments}}, token)
            msg = self._parse(raw)
            if status == 401 and attempt == 0:
                continue
            if not isinstance(msg, dict):
                raise OfficialMcpError(f"unexpected response from Robin MCP (HTTP {status})")
            if msg.get("error"):
                err = msg["error"]
                if attempt == 0 and str(err.get("code")) in ("-32001", "401"):
                    continue
                raise OfficialMcpError(str(err.get("message") or err))
            result = msg.get("result") or {}
            texts = [c.get("text", "") for c in result.get("content", []) if c.get("type") == "text"]
            payload = None
            if texts:
                try:
                    payload = json.loads(texts[0])
                except ValueError:
                    payload = texts[0]
            errors = payload.get("errors") if isinstance(payload, dict) else None
            if result.get("isError") or errors:
                detail = (errors[0].get("message") if errors else None) or (texts[0] if texts else "error")
                raise OfficialMcpError(str(detail))
            return payload if payload is not None else {"ok": True}
        raise OfficialMcpError("unauthorized to Robin MCP after refresh")
