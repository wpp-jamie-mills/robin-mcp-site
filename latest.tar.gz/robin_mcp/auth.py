"""Self-contained Robin OAuth sign-in (auth-code + PKCE, loopback redirect), with silent refresh.

Proven in the spike. Robin's authorize server (auth.robinpowered.com) accepts a dynamically
registered public client; it requires a redirect_uri and rejects the device_code grant, so we use
auth-code + PKCE with a loopback listener. Robin hands sign-in off to the org's IdP (Okta here); if
the browser already holds that session it is a click or two.

The token record lives only in the Keychain (keychain.py): JSON
``{client_id, access_token, refresh_token, expires_at, scope, org_id}``. The 1-hour access token is
renewed silently from the refresh token; the browser is only needed when there is no usable refresh
token.

Two ways to wait, mirroring outlook-okta:
- ``wait=True`` (the terminal commands): open the browser and block until the callback arrives.
- ``wait=False`` (the MCP server): a tool call cannot block for minutes, so the sign-in runs in a
  background thread and ``SignInRequired`` carries instructions back to the model.

IMPORTANT: this requests only scopes the authorize server will issue. ``event:cancel`` and
``reservation:seat:read`` are rejected as invalid by Robin (the consent page errors and nothing is
granted), so they are NOT requested — booking cancellation and desk-reservation reads are out of
reach for a self-registered client (see PLAN.md §0.5).
"""
from __future__ import annotations

import base64
import hashlib
import http.server
import json
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass

from . import config

AUTH = "https://auth.robinpowered.com"
REDIRECT_HOST, REDIRECT_PORT = "127.0.0.1", 8765
REDIRECT_URI = f"http://{REDIRECT_HOST}:{REDIRECT_PORT}/callback"
ACCOUNT = "default"  # single user per machine; the org is pinned in config and stored in the record
UA = "robin-mcp"
REFRESH_MARGIN_S = 90

# Only scopes the authorize server will actually issue (verified). No event:cancel / reservation:seat:read
# (both rejected as "Invalid scope"). `bot` IS granted and is what lets our token call Robin's own hosted
# MCP server (official_mcp.py) for actions the REST API won't do for us (book_space, remove_space).
SCOPES = (
    "bot identity identity.organizations user:read spaces:read places:read "
    "bookings:read bookings:write visits:read scheduling:events:read scheduling:events:write "
    "reservation:seat:manage settings:user:read directory:users:read directory:organizations:read offline_access"
)


class AuthError(RuntimeError):
    """A token could not be obtained."""


class OAuthError(AuthError):
    def __init__(self, error: str, description: str = "") -> None:
        super().__init__(f"{error}: {description}" if description else error)
        self.error = error


class SignInRequired(AuthError):
    """The owner must finish a sign-in in the browser; the message says how."""


# --------------------------------------------------------------------------- HTTP


def _post_form(url: str, form: dict[str, str]) -> dict:
    req = urllib.request.Request(url, data=urllib.parse.urlencode(form).encode(),
                                 headers={"User-Agent": UA, "Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read() or b"{}")
        except ValueError:
            body = {}
        raise OAuthError(body.get("error") or f"HTTP {exc.code}", body.get("error_description") or "") from exc


def _post_json(url: str, payload: dict) -> dict:
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"User-Agent": UA, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return json.load(resp)
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read() or b"{}")
        except ValueError:
            body = {}
        raise OAuthError(body.get("error") or f"HTTP {exc.code}",
                         body.get("error_description") or body.get("message") or "") from exc


def token_claims(access_token: str) -> dict:
    """An access token's claims (unverified; for labelling only, never a security decision)."""
    try:
        payload = access_token.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
    except (IndexError, ValueError):
        return {}


# --------------------------------------------------------------------------- token store


def _service() -> str:
    return config.service()


def load_record() -> dict:
    from . import keychain

    try:
        raw = keychain.get(_service(), ACCOUNT)
    except OSError as exc:
        # The Keychain can't be read (locked, or a non-interactive session, errSecInteractionNotAllowed).
        # Treat it as no stored session rather than crashing; the next tool asks the owner to sign in.
        print(f"robin-mcp: couldn't read the Keychain ({exc}); treating as signed out.", file=sys.stderr)
        return {}
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except ValueError:
        return {}


def save_record(record: dict) -> None:
    from . import keychain

    keychain.put(_service(), ACCOUNT, json.dumps(record).encode())


def clear_record() -> bool:
    from . import keychain

    return keychain.delete(_service(), ACCOUNT)


def _store_tokens(record: dict, tok: dict) -> dict:
    record = {**record}
    record["access_token"] = tok["access_token"]
    if tok.get("refresh_token"):
        record["refresh_token"] = tok["refresh_token"]
    record["expires_at"] = int(time.time()) + int(tok.get("expires_in") or 3600)
    record["scope"] = tok.get("scope") or record.get("scope")
    claims = token_claims(tok["access_token"])
    sub = str(claims.get("sub") or "")
    if sub.startswith("user:id:"):
        record["user_id"] = sub.split(":")[-1]
    if claims.get("tid"):
        record["org_id"] = str(claims["tid"])
    save_record(record)
    return record


# --------------------------------------------------------------------------- dynamic client registration


def ensure_client(record: dict) -> str:
    """The registered client id, registering one on first use. Stored in the record."""
    if record.get("client_id"):
        return record["client_id"]
    resp = _post_json(f"{AUTH}/register", {
        "client_name": "robin-mcp (local)",
        "token_endpoint_auth_method": "none",
        "grant_types": ["authorization_code", "refresh_token"],
        "response_types": ["code"],
        "redirect_uris": [REDIRECT_URI],
        "scope": SCOPES,
    })
    client_id = str(resp.get("client_id") or "")
    if not client_id:
        raise AuthError(f"client registration returned no client_id: {resp}")
    record["client_id"] = client_id
    save_record(record)
    return client_id


# --------------------------------------------------------------------------- PKCE loopback sign-in


def _pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def _open_browser(url: str) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.run(["/usr/bin/open", url], check=False, capture_output=True)
        else:
            import webbrowser

            webbrowser.open(url)
    except Exception:  # noqa: BLE001,S110 - best-effort; the URL is also printed/returned
        pass


@dataclass(frozen=True)
class SignInPrompt:
    url: str
    expires_at: float  # monotonic

    def instructions(self, now: float) -> str:
        minutes = max(1, round((self.expires_at - now) / 60))
        opened = " (it should have opened already)" if sys.platform == "darwin" else ""
        return (f"Sign-in needed. A Robin sign-in page opened in your browser{opened}; click Allow to "
                f"authorise robin-mcp (sign in to Robin/Okta if asked). If it didn't open, go to: {self.url}  "
                f"You have about {minutes} minutes. Then ask again.")


class PkceSignIn:
    """One auth-code + PKCE sign-in with a loopback listener."""

    def __init__(self, record: dict, *, timeout_s: int = 600) -> None:
        self.record = record
        self.timeout_s = timeout_s
        self._verifier, self._challenge = _pkce_pair()
        self._state = secrets.token_urlsafe(24)
        self._result: dict[str, str] = {}
        self._done = threading.Event()
        self._server: http.server.HTTPServer | None = None
        self.prompt: SignInPrompt | None = None

    def start(self) -> SignInPrompt:
        client_id = ensure_client(self.record)
        flow = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != "/callback":
                    self.send_response(404)
                    self.end_headers()
                    return
                flow._result = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<!doctype html><meta charset=utf-8>"
                                 b"<h3>Robin sign-in received. You can close this tab and return to Claude.</h3>")
                flow._done.set()

            def log_message(self, *a):  # keep the code out of logs
                pass

        try:
            self._server = http.server.HTTPServer((REDIRECT_HOST, REDIRECT_PORT), Handler)
        except OSError as exc:
            raise AuthError(f"cannot listen on {REDIRECT_URI} for the sign-in redirect: {exc}") from exc
        threading.Thread(target=self._server.serve_forever, daemon=True, name="robin-oauth-callback").start()
        url = f"{AUTH}/api/oauth/authorize?" + urllib.parse.urlencode({
            "response_type": "code", "client_id": client_id, "redirect_uri": REDIRECT_URI,
            "scope": SCOPES, "state": self._state,
            "code_challenge": self._challenge, "code_challenge_method": "S256",
        })
        _open_browser(url)
        self.prompt = SignInPrompt(url=url, expires_at=time.monotonic() + self.timeout_s)
        return self.prompt

    def wait(self) -> dict:
        """Block until the callback arrives, then exchange the code for tokens and store them."""
        try:
            if not self._done.wait(self.timeout_s):
                raise AuthError("the sign-in timed out before it was approved; ask again for a new sign-in")
            if self._result.get("state") != self._state:
                raise AuthError("sign-in state mismatch; please try signing in again")
            if "error" in self._result:
                raise OAuthError(self._result["error"], self._result.get("error_description", ""))
            tok = _post_form(f"{AUTH}/token", {
                "grant_type": "authorization_code", "code": self._result["code"],
                "redirect_uri": REDIRECT_URI, "client_id": self.record["client_id"],
                "code_verifier": self._verifier,
            })
            return _store_tokens(self.record, tok)
        finally:
            if self._server is not None:
                self._server.shutdown()


def port_available() -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((REDIRECT_HOST, REDIRECT_PORT))
            return True
        except OSError:
            return False


# --------------------------------------------------------------------------- refresh + access token


def _refresh(record: dict) -> dict:
    tok = _post_form(f"{AUTH}/token", {
        "grant_type": "refresh_token", "refresh_token": record["refresh_token"],
        "client_id": record["client_id"],
    })
    return _store_tokens(record, tok)


# Background sign-in state (one at a time), mirroring outlook-okta's _Pending.
_pending: _Pending | None = None
_signed_in = False
_lock = threading.Lock()


class _Pending:
    def __init__(self, flow: PkceSignIn) -> None:
        self.flow = flow
        self.record: dict | None = None
        self.error: BaseException | None = None
        self.thread = threading.Thread(target=self._run, daemon=True, name="robin-sign-in")

    def _run(self) -> None:
        try:
            self.record = self.flow.wait()
        except BaseException as exc:  # noqa: BLE001 - reported to the next caller
            self.error = exc


def access_token(force_login: bool = False, wait: bool = True) -> tuple[str, int]:
    """Return (access token, seconds until expiry), refreshing silently where possible.

    With a needed sign-in: ``wait`` blocks until the browser flow completes; otherwise it starts the
    flow in the background and raises SignInRequired with instructions."""
    global _pending, _signed_in
    with _lock:
        if _pending is not None and not _pending.thread.is_alive():
            done = _pending
            _pending = None
            if done.record is not None:
                _signed_in = True
                record = done.record
                return record["access_token"], max(0, record.get("expires_at", 0) - int(time.time()))
            # else it failed/expired: fall through to try refresh or start again
        if _pending is not None:
            raise SignInRequired(_pending.flow.prompt.instructions(time.monotonic()))

    record = load_record()
    if not force_login and record.get("refresh_token") and record.get("client_id"):
        try:
            record = _refresh(record)
            return record["access_token"], max(0, record.get("expires_at", 0) - int(time.time()))
        except AuthError as exc:
            print(f"robin-mcp: refresh failed ({exc}); a new sign-in is needed.", file=sys.stderr)

    flow = PkceSignIn(record)
    prompt = flow.start()
    print(prompt.instructions(time.monotonic()), file=sys.stderr)
    if wait:
        record = flow.wait()
        with _lock:
            _signed_in = True
        return record["access_token"], max(0, record.get("expires_at", 0) - int(time.time()))
    with _lock:
        _pending = _Pending(flow)
        _pending.thread.start()
    raise SignInRequired(prompt.instructions(time.monotonic()))


def begin_sign_in() -> dict:
    """Make sure a sign-in is under way (or done) and return the status. Never blocks for the owner."""
    try:
        access_token(wait=False)
    except SignInRequired:
        pass
    except AuthError as exc:
        return {"state": "failed", "error": str(exc)}
    return sign_in_status()


def sign_in_status() -> dict:
    """Where the sign-in stands, without starting one or consuming its result."""
    global _pending, _signed_in
    with _lock:
        if _pending is not None:
            if _pending.thread.is_alive():
                return {"state": "pending", "url": _pending.flow.prompt.url,
                        "expires_in_s": max(0, int(_pending.flow.prompt.expires_at - time.monotonic()))}
            done = _pending
            _pending = None
            if done.record is not None:
                _signed_in = True
                return {"state": "signed_in", "user": signed_in_as()}
            return {"state": "failed", "error": str(done.error or "sign-in did not finish")}
        if _signed_in or load_record().get("refresh_token"):
            return {"state": "signed_in", "user": signed_in_as()}
        return {"state": "idle"}


def sign_out() -> dict:
    """Forget the sign-in: delete the stored token. No network."""
    global _pending, _signed_in
    with _lock:
        _pending = None
        _signed_in = False
    removed = clear_record()
    return {"state": "signed_out", "removed": removed}


def signed_in_as() -> str:
    record = load_record()
    tok = record.get("access_token")
    if not tok:
        return ""
    claims = token_claims(tok)
    sub = str(claims.get("sub") or "")
    return sub.split(":")[-1] if sub else (record.get("user_id") or "")


def status() -> dict:
    """Summary for the CLI / auth-status tool. No secrets."""
    record = load_record()
    now = int(time.time())
    return {
        "signed_in": bool(record.get("refresh_token")),
        "registered": bool(record.get("client_id")),
        "org_id": record.get("org_id") or config.org(),
        "user_id": record.get("user_id"),
        "scope": record.get("scope"),
        "access_token_expires_in_s": (record.get("expires_at", 0) - now) if record.get("expires_at") else None,
    }


class TokenCache:
    """Hands out an access token, refreshing shortly before expiry (a chat can outlast one token)."""

    def __init__(self, acquire: Callable[..., tuple[str, int]] = access_token,
                 now: Callable[[], float] = time.monotonic) -> None:
        self._acquire = acquire
        self._now = now
        self._token: str | None = None
        self._expires_at = 0.0

    def __call__(self, force_refresh: bool = False) -> str:
        if force_refresh or self._token is None or self._now() >= self._expires_at - REFRESH_MARGIN_S:
            self._token, lifetime = self._acquire(force_login=False, wait=False)
            self._expires_at = self._now() + lifetime
        return self._token
