"""HTTP access to Robin as the signed-in user: the documented REST API and the internal GraphQL
gateway, both authenticated with the OAuth access token (``Authorization: Bearer`` + ``Tenant-Id``).

The token stays inside this process; callers get request *results*, never the token. Requests are
restricted to Robin hosts. On a 401 the token is force-refreshed once and the call retried.

Only pinned GraphQL operation documents (operations.py) are sent — never free-form GraphQL.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable

from . import operations

REST_BASE = "https://api.robinpowered.com/v1.0"
GQL_URL = "https://federation-gateway.robinpowered.com/graphql"
ALLOWED_HOSTS = {"api.robinpowered.com", "federation-gateway.robinpowered.com"}
UA = "robin-mcp"
TIMEOUT = 30


class RobinError(RuntimeError):
    """An API call failed. ``status`` is the HTTP status (or None); ``scope`` names a missing scope if any."""

    def __init__(self, message: str, status: int | None = None, scope: str | None = None) -> None:
        super().__init__(message)
        self.status = status
        self.scope = scope


class RobinClient:
    def __init__(self, token_provider: Callable[..., str], org: str) -> None:
        self._token = token_provider
        self.org = str(org)

    # ------------------------------------------------------------------ low-level

    def _headers(self, token: str, extra: dict | None = None) -> dict:
        h = {"User-Agent": UA, "Authorization": f"Bearer {token}", "Tenant-Id": self.org, "Accept": "application/json"}
        h.update(extra or {})
        return h

    def _send(self, method: str, url: str, *, headers: dict, body: bytes | None) -> tuple[int, bytes]:
        host = urllib.parse.urlparse(url).hostname
        if urllib.parse.urlparse(url).scheme != "https" or host not in ALLOWED_HOSTS:
            raise RobinError(f"refusing request to disallowed host: {host}")
        req = urllib.request.Request(url, method=method, data=body, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read() or b""

    # ------------------------------------------------------------------ REST

    def rest(self, method: str, path: str, *, params: dict | None = None, json_body: dict | None = None):
        """Call the REST API and return the unwrapped ``data`` (or raise RobinError). Refreshes once on 401."""
        qs = "?" + urllib.parse.urlencode(params, doseq=True) if params else ""
        url = f"{REST_BASE}{path}{qs}"
        body = json.dumps(json_body).encode() if json_body is not None else None
        extra = {"Content-Type": "application/json"} if json_body is not None else None
        for attempt in (0, 1):
            token = self._token(force_refresh=attempt == 1)
            status, raw = self._send(method, url, headers=self._headers(token, extra), body=body)
            if status == 401 and attempt == 0:
                continue
            return self._unwrap_rest(status, raw)
        raise RobinError("unauthorized after refresh", status=401)

    @staticmethod
    def _unwrap_rest(status: int, raw: bytes):
        try:
            payload = json.loads(raw) if raw else {}
        except ValueError:
            payload = {}
        meta = payload.get("meta") or {} if isinstance(payload, dict) else {}
        errors = meta.get("errors") or []
        if 200 <= status < 300 and not errors:
            return payload.get("data") if isinstance(payload, dict) else payload
        msg = meta.get("message") or (errors[0].get("message") if errors else f"HTTP {status}")
        scope = None
        for e in errors:
            det = (e.get("details") or {}) if isinstance(e, dict) else {}
            if det.get("scope"):
                scope = det["scope"]
        raise RobinError(str(msg), status=status, scope=scope)

    # ------------------------------------------------------------------ GraphQL (pinned ops)

    def gql(self, op_name: str, variables: dict):
        """Run a pinned GraphQL operation (operations.py) and return its ``data`` (or raise RobinError)."""
        doc = operations.DOCUMENTS.get(op_name)
        if not doc:
            raise RobinError(f"unknown GraphQL operation {op_name!r}")
        body = json.dumps({"query": doc, "variables": variables, "operationName": op_name}).encode()
        extra = {"Content-Type": "application/json", "x-requested-with": "robin-mcp"}
        for attempt in (0, 1):
            token = self._token(force_refresh=attempt == 1)
            status, raw = self._send("POST", GQL_URL, headers=self._headers(token, extra), body=body)
            try:
                payload = json.loads(raw) if raw else {}
            except ValueError:
                payload = {}
            errors = payload.get("errors") if isinstance(payload, dict) else None
            if errors and attempt == 0 and _is_auth_error(errors):
                continue  # token may be stale; refresh and retry once
            if errors:
                msg = "; ".join(str(e.get("message", "")).split(".")[0] for e in errors)[:200]
                raise RobinError(msg or "GraphQL error", status=status)
            return (payload.get("data") if isinstance(payload, dict) else None) or {}
        raise RobinError("GraphQL unauthorized after refresh", status=401)


def _is_auth_error(errors) -> bool:
    text = json.dumps(errors).lower()
    return "not authenticated" in text or "unauthenticated" in text or "missing scope" in text
