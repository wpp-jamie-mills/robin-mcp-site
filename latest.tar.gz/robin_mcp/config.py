"""Configuration for the Robin MCP server and CLI.

No org-specific values are hard-coded. Values resolve in this order (first wins):
  1. process environment variable (e.g. ROBIN_MCP_ORG) — the Claude Desktop extension maps its
     settings to these;
  2. the file named by $ROBIN_MCP_ENV;
  3. ~/.config/robin-mcp/config.env (the user-global config).

Writes go to $ROBIN_MCP_ENV, else ~/.config/robin-mcp/config.env.

Keys:
  ROBIN_MCP_ORG            Robin organisation id or slug. Pinned: every API call sends it as Tenant-Id.
                           Blank -> resolved once from /me/organizations at sign-in.
  ROBIN_MCP_SERVICE        Keychain service name for the stored token (default: robin-mcp).
  ROBIN_MCP_ALLOW_WRITES   booking (robin_book_room) is ON by default; set "0"/"false" to disable it.
  ROBIN_MCP_DEFAULT_LOCATION  Optional default building id, used by robin_find_rooms when a search names
                           neither a building nor a floor.
  ROBIN_MCP_DEFAULT_LEVEL  Optional default floor (level) id, used alongside the default building when a
                           robin_find_rooms search names neither a building nor a floor.
  ROBIN_MCP_APPROVALS      "chat" (default) or "auto" (approval card, config-file mode).
  ROBIN_MCP_CHECK_UPDATES  "1"/"true" to check the landing page once a day (default: on).
"""
from __future__ import annotations

import os
from pathlib import Path

KEYS = (
    "ROBIN_MCP_ORG", "ROBIN_MCP_SERVICE", "ROBIN_MCP_ALLOW_WRITES",
    "ROBIN_MCP_DEFAULT_LOCATION", "ROBIN_MCP_DEFAULT_LEVEL", "ROBIN_MCP_APPROVALS",
    "ROBIN_MCP_CHECK_UPDATES",
)
DEFAULT_SERVICE = "robin-mcp"
_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}


def _user_env() -> Path:
    return Path.home() / ".config" / "robin-mcp" / "config.env"


def _candidate_files() -> list[Path]:
    paths: list[Path] = []
    override = os.environ.get("ROBIN_MCP_ENV")
    if override:
        paths.append(Path(override).expanduser())
    paths.append(_user_env())
    return paths


def _parse(path: Path) -> dict[str, str]:
    data: dict[str, str] = {}
    try:
        text = path.read_text()
    except OSError:
        return data
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data


def _file_values() -> dict[str, str]:
    for path in _candidate_files():
        if path.is_file():
            return _parse(path)
    return {}


def get(key: str, default: str | None = None) -> str | None:
    """Resolve a config value: process env, then the config file, then default.
    An unfilled ``${...}`` placeholder (from a Desktop extension manifest) counts as unset."""
    value = os.environ.get(key)
    if value and not value.startswith("${"):
        return value
    return _file_values().get(key, default)


def service() -> str:
    return get("ROBIN_MCP_SERVICE") or DEFAULT_SERVICE


def org() -> str | None:
    return get("ROBIN_MCP_ORG") or None


def allow_writes() -> bool:
    """Booking is ON by default; only an explicit false/0/no/off disables it."""
    return (get("ROBIN_MCP_ALLOW_WRITES", "") or "").strip().lower() not in _FALSE


def default_location() -> str | None:
    return get("ROBIN_MCP_DEFAULT_LOCATION") or None


def default_level() -> str | None:
    return get("ROBIN_MCP_DEFAULT_LEVEL") or None


def write_path() -> Path:
    override = os.environ.get("ROBIN_MCP_ENV")
    if override:
        return Path(override).expanduser()
    return _user_env()


def set_values(**kwargs: str | None) -> Path:
    """Persist the given keys to the config file, preserving others. 0600."""
    path = write_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    values = _parse(path) if path.is_file() else {}
    for key, value in kwargs.items():
        if value is not None:
            values[key] = value
    lines = ["# robin-mcp configuration (do not commit — the token lives in the Keychain, not here)"]
    lines += [f"{key}={values[key]}" for key in KEYS if key in values]
    path.write_text("\n".join(lines) + "\n")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return path


RUN_MODE_ENV = "MCP_RUN_MODE"  # "config": started from a Claude Desktop mcpServers entry (bin/robin-mcp)


def config_file_mode() -> bool:
    """True when started from a Claude Desktop mcpServers entry (bin/robin-mcp sets $MCP_RUN_MODE=config)."""
    return os.environ.get(RUN_MODE_ENV, "").strip().lower() == "config"
