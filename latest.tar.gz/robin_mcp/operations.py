"""Pinned GraphQL operation documents for Robin's internal gateway.

Only the operations verified to work with the user OAuth token are kept (PLAN.md §0.5). Each is the
exact document the web app sends, so field shapes match. No free-form GraphQL is ever sent.
"""
from __future__ import annotations

DOCUMENTS: dict[str, str] = {
    # My weekly in-office plan (which days I'm in a given building). Verified.
    "GetWeeklyScheduleForUser":
        "query GetWeeklyScheduleForUser($userId: String!, $locationId: String!) { "
        "employeeVisit { getWeeklyScheduleForUser(userId: $userId, locationId: $locationId) "
        "{ id mon tue wed thu fri sat sun } } }",
    # People search by name/email. Verified (needs directory:users:read).
    "GetUsersByKeyword":
        "query GetUsersByKeyword($query: String!, $organizationId: ID!) { "
        "getUsersByKeyword(organizationId: $organizationId, keyword: $query) "
        "{ id name avatar primaryEmail { email } } }",
    # My notification settings. Verified (needs settings:user:read).
    "GetUserNotificationSettings":
        "query GetUserNotificationSettings($userId: ID!) { "
        "getUserNotificationSettings(userId: $userId) { ownerId name values } }",
}
