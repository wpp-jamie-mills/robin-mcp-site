"""The tool catalogue: schemas, descriptions and dispatch. Read tools are always available; the write
tools (robin_book_room, robin_cancel_booking) are registered by the server only when writes are turned on.

Scope note (PLAN.md §0.5): this self-contained OAuth build covers rooms (find/book/cancel/schedule),
my bookings, people, working hours, weekly schedule and notification settings. It cannot reach
desks/visits (Robin won't grant those scopes to a self-registered client)."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from . import directory, rooms
from .client import RobinClient

INSTRUCTIONS = (
    "Act on the user's Robin workplace account as themselves. Call robin_auth_status first if unsure a "
    "session exists. To book a meeting room: robin_locations to find a building, robin_find_rooms for a free "
    "room in a time window, then robin_book_room. Times may be given in the building's local zone. "
    "To put a room on an EXISTING meeting: robin_calendar to find the meeting, then robin_add_room(event_id, "
    "space_id). To FREE a room from a meeting without cancelling the meeting: robin_cancel_room(event_id, "
    "space_id) — robin_calendar(with_space=true) lists meetings that hold a room. To CANCEL a whole booking "
    "you made and free its room: robin_cancel_booking(event_id) — event_id from robin_my_bookings or "
    "robin_book_room; this is how to undo a standalone robin_book_room booking (which IS its own meeting, so "
    "robin_cancel_room can't touch it). robin_suggest_rooms suggests rooms for a meeting. "
    "(add_room/cancel_room/calendar/suggest_rooms run through Robin's own hosted MCP using your token; "
    "book_room and cancel_booking go direct to Robin's REST API.)"
)


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    handler: Callable[..., Any]
    properties: dict = field(default_factory=dict)
    required: tuple[str, ...] = ()
    write: bool = False

    def schema(self) -> dict:
        return {"type": "object", "properties": self.properties,
                "required": list(self.required), "additionalProperties": False}


_STR = {"type": "string"}
_INT = {"type": "integer"}
_BOOL = {"type": "boolean"}


TOOLS: list[Tool] = [
    Tool("robin_whoami", "You and your Robin organisations, default building and timezone.",
         lambda c: directory.whoami(c)),
    Tool("robin_locations", "List your Robin buildings with id, name, timezone and address.",
         lambda c: rooms.locations(c)),
    Tool("robin_levels", "List a building's floors (levels) with their id and name (e.g. 8, Ground Floor). "
         "Give a location_id from robin_locations. Use a floor's level_id with robin_find_rooms, or set it as "
         "your default floor.",
         lambda c, location_id: rooms.levels(c, location_id),
         {"location_id": {"type": ["integer", "string"]}}, ("location_id",)),
    Tool("robin_find_rooms",
         "Find free, bookable meeting rooms for a time window. Give a location_id (building) or level_id "
         "(floor); if you give neither, it falls back to the owner's configured default building and floor "
         "(so a bare 'find a room at 12:00' searches there), and only errors if no default is set. start/end "
         "are ISO date-times (an offset is honoured; otherwise the building's timezone is used). Returns each "
         "room's id, name, capacity, floor (level_id) and whether it's bookable.",
         lambda c, **k: rooms.find_rooms(c, **k),
         {"start": _STR, "end": _STR, "location_id": {"type": ["integer", "string"]},
          "level_id": {"type": ["integer", "string"]}, "min_capacity": _INT, "time_zone": _STR,
          "include_unbookable": _BOOL},
         ("start", "end")),
    Tool("robin_room_details", "Everything Robin records about one room (capacity, type, amenities, floor, policies).",
         lambda c, space_id: rooms.room_details(c, space_id),
         {"space_id": {"type": ["integer", "string"]}}, ("space_id",)),
    Tool("robin_room_schedule", "A room's bookings between two ISO date-times.",
         lambda c, space_id, after, before: rooms.room_schedule(c, space_id, after=after, before=before),
         {"space_id": {"type": ["integer", "string"]}, "after": _STR, "before": _STR},
         ("space_id", "after", "before")),
    Tool("robin_my_bookings", "Your room bookings between two ISO date-times.",
         lambda c, after, before, limit=50: rooms.my_bookings(c, after=after, before=before, limit=limit),
         {"after": _STR, "before": _STR, "limit": _INT}, ("after", "before")),
    Tool("robin_find_people", "Search colleagues in your organisation by name or email.",
         lambda c, query: directory.find_people(c, query), {"query": _STR}, ("query",)),
    Tool("robin_person", "A colleague's profile: name, email, timezone and working hours.",
         lambda c, user_id: directory.person(c, user_id), {"user_id": {"type": ["integer", "string"]}}, ("user_id",)),
    Tool("robin_working_hours", "Your configured working hours (per weekday).",
         lambda c: directory.working_hours(c)),
    Tool("robin_weekly_schedule",
         "Your weekly in-office plan for a building: which weekdays you're scheduled in. Give its location_id.",
         lambda c, location_id, user_id=None: directory.weekly_schedule(c, location_id, user_id),
         {"location_id": {"type": ["integer", "string"]}, "user_id": {"type": ["integer", "string"]}},
         ("location_id",)),
    Tool("robin_notification_settings", "Your Robin notification settings.",
         lambda c: directory.notification_settings(c)),
    # ---- write (registered only when writes are on) ----
    Tool("robin_book_room",
         "Book a meeting room directly, as you. Give the room's space_id (from robin_find_rooms), start and end "
         "(ISO date-times), and a title. Optionally invitees (emails), description, private. Re-checks nothing "
         "server-side beyond Robin's own policies; returns the exact booked times and the event id. It cannot be "
         "cancelled by this server afterwards.",
         lambda c, **k: rooms.book_room(c, **k),
         {"space_id": {"type": ["integer", "string"]}, "start": _STR, "end": _STR, "title": _STR,
          "invitees": {"type": "array", "items": _STR}, "description": _STR, "private": _BOOL,
          "time_zone": _STR, "allow_long": _BOOL},
         ("space_id", "start", "end", "title"), write=True),
    Tool("robin_cancel_booking",
         "Cancel a booking you made and free its room. Give the booking's event_id (from robin_my_bookings, or the "
         "result of robin_book_room). This cancels the WHOLE booking, so it's the way to undo a standalone "
         "robin_book_room booking; use robin_cancel_room instead when you only want to take a room off a meeting "
         "that should stay. If the booking has other invitees, they are told it's cancelled.",
         lambda c, event_id: rooms.cancel_booking(c, event_id=event_id),
         {"event_id": _STR}, ("event_id",), write=True),
]

BY_NAME = {t.name: t for t in TOOLS}
READ_TOOLS = [t for t in TOOLS if not t.write]
WRITE_TOOLS = [t for t in TOOLS if t.write]


def run_tool(client: RobinClient, name: str, inp: dict) -> Any:
    tool = BY_NAME.get(name)
    if tool is None:
        raise KeyError(f"unknown tool {name!r}")
    return tool.handler(client, **inp)
